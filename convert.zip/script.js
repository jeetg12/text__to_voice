let button = document.getElementById('button');
let button2 = document.getElementById('button2');
let textarea = document.getElementById('textarea');
let speech = new SpeechSynthesisUtterance();
let select = document.querySelector('select');
let voices =[];

button.addEventListener('click',()=>{
    console.log("start");
    speech.text = textarea.value;
    window.speechSynthesis.speak(speech);
});
window.speechSynthesis.onvoiceschanged=()=>{
    voices=window.speechSynthesis.getVoices();
    // speech.voice = voices[Math.random()+1];

voices.forEach((voice,i) =>{

     const option = document.createElement('option');
     option.value =i;
    //  option.textContent = `${i+1}-${voice.name}`;
    option.innerHTML =` 
    <option>${i+1}-${voice.name}</option>
    `
     select.appendChild(option);
    
}
       
);

};

select.addEventListener('change',()=>{
    speech.voice =voices[select.value];
});

button2.addEventListener('click',()=>{

    let recognition = new webkitSpeechRecognition();
    recognition.lang ='en-GB';
    recognition.onresult =function(events){
        console.log(events);
        console.log(events.results[0][0].transcript);
        textarea.value = events.results[0][0].transcript;
    }
    recognition.start();
});

